# HW2017MobileDevNewsApp

This project should build and run, but no data will load. You'll need to
1) Add your newsapi.org API key as a string resource named "news_api_key". This should allow loading content in the "browse" tab.
2) Get a google-services.json file which associates this with a Firebase project. This should allow loading content in the other two tabs.
